//
// plugin.js
// Copyright (c) 2017 LSTORE
//

@import "lib/runtime.js"

function generateCalendarGrid(context)
{
    // Load the bundle with native code if needed
    if (NSClassFromString("CLGMainWindowController") == null) {
        runtime.loadBundle("Calgen.bundle");
    }
    // Update the plugin context
    [CLGSketch setPluginContextDictionary:context];

    // Show the plugin configuration window
    var controller = [CLGMainWindowController defaultController];
    [controller showWindow:nil];
}
