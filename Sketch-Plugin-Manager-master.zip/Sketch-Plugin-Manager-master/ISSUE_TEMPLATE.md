### Description

[//]: # (Include a detailed description of the problem)


### OS X Version

[//]: # (e.g. 10.12.4; To find the version number, go to the Apple menu -> About This Mac.)


### Sketch Plugin Manager Version

[//]: # (To find the version number, in Sketch go to Preferences > Plugins and look for the gray number next to "Sketch Plugin Manager".)


### Screenshot

[//]: # (Include a screenshot or screen recording, if applicable)


### Logs

[//]: # (Attach a .txt file containing logs for Sketch Plugin Manager. For instructions on how to export logs:)
[//]: # (For v1.4+: https://github.com/mludowise/Sketch-Plugin-Manager/wiki/Exporting-Logs-v1.4-or-higher)
[//]: # (For v1.3 or lower: https://github.com/mludowise/Sketch-Plugin-Manager/wiki/Exporting-Logs---v1.3-or-lower)
