function showMessage (message, context) {
	context.document.showMessage(message);
}