var Logodrop = Logodrop || {};
Logodrop.config = {
  API_URL: 'https://api.iconscout.com',
  ACCESS_TOKEN: 'rzSWZK6TQEwrj4jvVuuxP7CJu6qaSrPS',
  MANIFEST: 'https://raw.githubusercontent.com/Iconscout/logodrop/master/Logodrop.sketchplugin/Contents/Sketch/manifest.json'
};

Logodrop.enums = {
  EXPORT_MODE: {
    ALL: 'all',
    SELECTION: 'selection',
  },
};

export default Logodrop