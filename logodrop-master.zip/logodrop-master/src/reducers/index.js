import { combineReducers } from 'redux'
import results from './results'
// import visibilityFilter from './visibilityFilter'

const sketchLogosApp = combineReducers({
	results
})

export default sketchLogosApp