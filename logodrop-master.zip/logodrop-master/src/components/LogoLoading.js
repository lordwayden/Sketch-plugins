import React from 'react'

const LogoLoading = () => (
	<a
		href="#"
		className="logoLoading animated-background img-thumbnail"
		>
	</a>
)

export default LogoLoading