=======

### First Install

First use? you need to watch ([THIS VIDEO](http://recordit.co/2PMTB04Jav))
##### Please if you have an issue, first watch the video.

If you don't see any icons, please make sure you have installed ttf files of your icon fonts.

=======

### Descriptions of Commands

Command             	| Description
----------------------- | -----------------------------------------------------------------------------------------------
Install a Font-Bundle   | Install a newly downloaded font bundle.
Export your Font-Bundle | Export or backup all icon fonts previously installed by you. Recommended before installing a new version of the plugin.
Install a Font          | Install a newly downloaded icon font - containing an svg font file.
Remove a Font 			| Remove a previously downloaded icon font.
Grid Insert 			| Insert an icon by searching a table grid of all icons.
Name Insert 			| Insert an icon by its name.
HTML of Selected Icon   | To use an icon on web or mobile, select it and run this command.
