@import "helpers.js";

var aboutIdea = function(context) {
    Helpers.openUrl("https://www.facebook.com/popovanasta");
}