@import "helpers.js";

var aboutAuthor = function(context) {
    Helpers.openUrl("https://www.facebook.com/kirenkov.vitaliy");
}