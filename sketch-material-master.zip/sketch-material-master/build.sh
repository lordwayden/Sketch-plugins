#!/bin/sh
rm -rf builds/sketch-material.sketchplugin
cp -R sketch-material.sketchplugin builds/sketch-material.sketchplugin
rm -rf builds/sketch-material.sketchplugin/Contents/Sketch/src
