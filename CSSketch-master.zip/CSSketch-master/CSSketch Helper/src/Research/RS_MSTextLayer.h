//
//  RS_MSTextLayer.h
//  CSSketch Helper
//
//  Created by John Coates on 10/12/15.
//  Copyright © 2015 John Coates. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <MonolithOSX/MONHook.h>

@interface RS_MSTextLayer : NSObject <MONHook>

@end
