# Update history

##### Nov 28, 2016
* 2.03 version, updated to also support v41 and earlier

##### July 11, 2016
* 2.02 version, updated to also support v39

##### May 10, 2016
* 2.01 version, updated to also support 3.8

##### Jan 27, 2016
* 1.01 version, updated to also support 3.5

##### Jan 24, 2016
* 1.0 version, supports Sketch 3.4
