# Slinky source
## v0.1.0

Slinky plugin is written in [Typescript](https://www.typescriptlang.org/).
To compile the code, you need to install [Node.js](https://nodejs.org/en/download/).

To install the compiler dependencies, inside this folder run: 

```
npm install
```

To compile the plugin code and watch files for changes,  run
```
npm start
```
