### Avoid using these definitions for your own project!

The definitions are *work in progress* and only satisfy this specific plugin in a hacky way :/

Hopefully someday someone will have the time to make this the standard way. Or better - Sketch API will transform to a better form.
