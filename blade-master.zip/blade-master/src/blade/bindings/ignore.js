/**
 * Created by jiamiu on 14-5-19.
 */

Binding.registry('ignore',{
    stopAutoApplyBindingForChildren : true
})