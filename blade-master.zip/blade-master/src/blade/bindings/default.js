/**
 * Created by jiamiu on 14-5-21.
 */

Binding.registry('default',function(  layer, args, outputRef  ){
    //we do nothing!
})